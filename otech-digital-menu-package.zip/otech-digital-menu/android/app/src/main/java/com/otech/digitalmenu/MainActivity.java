package com.otech.digitalmenu;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.format.Formatter;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Otech Digital Menu Android client.
 * Auto-finds PC server on same Wi-Fi (port 8080) and loads the live web app.
 * Start Otech on the PC first (Desktop shortcut).
 */
public class MainActivity extends AppCompatActivity {

    public static final String PREFS = "otech_prefs";
    public static final String KEY_SERVER = "server_url";
    public static final int SERVER_PORT = 8080;

    private WebView webView;
    private ProgressBar progressBar;
    private TextView statusBar;
    private SwipeRefreshLayout swipe;
    private SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean loadingServer = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        webView = findViewById(R.id.webview);
        progressBar = findViewById(R.id.progress);
        statusBar = findViewById(R.id.status_bar);
        swipe = findViewById(R.id.swipe);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setAllowFileAccess(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                statusBar.setText(getString(R.string.loading));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                swipe.setRefreshing(false);
                if (url != null && url.startsWith("http")) {
                    statusBar.setText(getString(R.string.online_team) + "  " + url);
                    try {
                        java.net.URI u = java.net.URI.create(url.split("\\?")[0]);
                        String origin = u.getScheme() + "://" + u.getHost()
                                + (u.getPort() > 0 ? ":" + u.getPort() : "");
                        prefs.edit().putString(KEY_SERVER, origin).apply();
                    } catch (Exception ignored) {}
                } else {
                    statusBar.setText(R.string.offline_mode);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    swipe.setRefreshing(false);
                    statusBar.setText(R.string.server_unreachable);
                    loadOfflineAssets();
                }
            }
        });

        swipe.setOnRefreshListener(this::connectToServer);
        connectToServer();
    }

    private void connectToServer() {
        if (loadingServer) return;
        loadingServer = true;
        progressBar.setVisibility(View.VISIBLE);
        statusBar.setText(R.string.searching_server);

        final String saved = prefs.getString(KEY_SERVER, null);
        executor.execute(() -> {
            String found = null;

            if (saved != null && isServerReachable(saved)) {
                found = normalizeBase(saved);
            }
            if (found == null) {
                found = scanLanForServer();
            }
            if (found == null && isServerReachable("http://10.0.2.2:" + SERVER_PORT)) {
                found = "http://10.0.2.2:" + SERVER_PORT;
            }

            final String url = found;
            mainHandler.post(() -> {
                loadingServer = false;
                if (url != null) {
                    prefs.edit().putString(KEY_SERVER, url).apply();
                    statusBar.setText(getString(R.string.connecting) + " " + url);
                    webView.loadUrl(url);
                } else {
                    statusBar.setText(R.string.no_server_offline);
                    loadOfflineAssets();
                    Toast.makeText(this, R.string.tip_set_server, Toast.LENGTH_LONG).show();
                }
                swipe.setRefreshing(false);
            });
        });
    }

    private String normalizeBase(String baseUrl) {
        String u = baseUrl.trim();
        if (!u.startsWith("http")) u = "http://" + u;
        if (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u;
    }

    private void loadOfflineAssets() {
        webView.loadUrl("file:///android_asset/www/index.html");
        statusBar.setText(R.string.offline_mode);
    }

    private boolean isServerReachable(String baseUrl) {
        try {
            String clean = baseUrl.replace("http://", "").replace("https://", "");
            if (clean.contains("/")) clean = clean.substring(0, clean.indexOf('/'));
            String host;
            int port = SERVER_PORT;
            if (clean.contains(":")) {
                String[] p = clean.split(":");
                host = p[0];
                port = Integer.parseInt(p[1]);
            } else {
                host = clean;
            }
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(host, port), 900);
                return true;
            }
        } catch (Exception e) {
            return false;
        }
    }

    private String scanLanForServer() {
        try {
            WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wifi == null) return null;
            int ipInt = wifi.getConnectionInfo().getIpAddress();
            if (ipInt == 0) return null;
            String myIp = Formatter.formatIpAddress(ipInt);
            String prefix = myIp.substring(0, myIp.lastIndexOf('.') + 1);

            int[] order = new int[254];
            int n = 0;
            order[n++] = 1;
            for (int i = 2; i <= 50; i++) order[n++] = i;
            for (int i = 100; i <= 180; i++) order[n++] = i;
            for (int i = 51; i <= 99; i++) order[n++] = i;
            for (int i = 181; i <= 254; i++) order[n++] = i;

            for (int k = 0; k < n; k++) {
                String host = prefix + order[k];
                if (host.equals(myIp)) continue;
                try (Socket socket = new Socket()) {
                    socket.connect(new InetSocketAddress(host, SERVER_PORT), 50);
                    return "http://" + host + ":" + SERVER_PORT;
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        } else if (id == R.id.action_reload) {
            connectToServer();
            return true;
        } else if (id == R.id.action_offline) {
            loadOfflineAssets();
            return true;
        } else if (id == R.id.action_about) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.app_name)
                    .setMessage(R.string.about_text)
                    .setPositiveButton(android.R.string.ok, null)
                    .show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        String saved = prefs.getString(KEY_SERVER, null);
        String cur = webView.getUrl();
        if (saved != null && cur != null && cur.startsWith("file://")) {
            connectToServer();
        }
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
