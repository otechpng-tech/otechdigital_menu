package com.otech.digitalmenu;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Set the host PC address on the same Wi‑Fi (e.g. http://192.168.1.25:8080).
 * Team devices all point to the same server for live shared data.
 */
public class SettingsActivity extends AppCompatActivity {

    private EditText serverInput;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.server_settings);
        }

        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        serverInput = findViewById(R.id.input_server);
        TextView help = findViewById(R.id.help_text);
        Button save = findViewById(R.id.btn_save);
        Button clear = findViewById(R.id.btn_clear);

        String current = prefs.getString(MainActivity.KEY_SERVER, "");
        serverInput.setText(current);

        help.setText(R.string.settings_help);

        save.setOnClickListener(v -> {
            String url = serverInput.getText().toString().trim();
            if (url.isEmpty()) {
                Toast.makeText(this, R.string.enter_server, Toast.LENGTH_SHORT).show();
                return;
            }
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "http://" + url;
            }
            // Ensure port if only IP given
            String withoutScheme = url.replace("http://", "").replace("https://", "");
            if (!withoutScheme.contains(":") && withoutScheme.matches("\\d+\\.\\d+\\.\\d+\\.\\d+")) {
                url = url + ":8080";
            }
            prefs.edit().putString(MainActivity.KEY_SERVER, url).apply();
            Toast.makeText(this, R.string.saved_restart, Toast.LENGTH_LONG).show();
            finish();
        });

        clear.setOnClickListener(v -> {
            prefs.edit().remove(MainActivity.KEY_SERVER).apply();
            serverInput.setText("");
            Toast.makeText(this, R.string.cleared_auto, Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
