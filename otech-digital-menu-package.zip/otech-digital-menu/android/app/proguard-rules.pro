# Otech Digital Menu – keep WebView
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
