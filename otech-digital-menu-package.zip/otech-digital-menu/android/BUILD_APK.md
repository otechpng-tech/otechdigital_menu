# Build Otech Digital Menu APK (Android Studio)

The Android app connects to the **same system** as the web app on your PC.
When the PC app is running on the same Wi‑Fi, the phone **auto-finds** it.

---

## Before you start

1. On the **PC**, run Otech (Desktop shortcut / `Setup.bat` / `Start_Otech_Menu.bat`).
2. Keep the black server window open.
3. Phone and PC must be on the **same Wi‑Fi**.

---

## Install Android Studio

1. Download: https://developer.android.com/studio  
2. Install with default options (Android SDK included).  
3. Open Android Studio once and finish the setup wizard.

---

## Open this project

1. Extract `otech-digital-menu-package.zip`.
2. Android Studio → **File → Open**.
3. Select the folder:  
   `otech-digital-menu/android`  
   (the folder that contains `settings.gradle` and `app/`).
4. Wait for **Gradle Sync** (first time may take several minutes).

If sync asks for SDK path, accept defaults.

---

## Run on a phone (debug)

1. On the phone: enable **Developer options** → **USB debugging**.
2. Connect USB (or use an emulator).
3. Click the green **Run** button.
4. App installs and opens.
5. It searches Wi‑Fi for the PC server (port 8080).
6. If not found: menu **⋮ → Server Settings** → enter  
   `http://192.168.x.x:8080`  
   (IP shown in the PC black window).

---

## Export APK to install on any phone

### Debug APK (quick)

1. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. When finished, click **locate**.
3. File path example:  
   `android/app/build/outputs/apk/debug/app-debug.apk`
4. Copy APK to the phone and open it to install  
   (allow “Install unknown apps” if asked).

### Release APK (recommended for staff phones)

1. **Build → Generate Signed Bundle / APK → APK**
2. **Create new** keystore (or use existing):
   - Choose a folder and password — **keep this keystore safe** for updates
3. Select **release**, finish the wizard.
4. APK path example:  
   `android/app/build/outputs/apk/release/app-release.apk`

---

## How the app works with the PC

| Step | What happens |
|------|----------------|
| 1 | PC runs Otech → server on port **8080** for all devices on Wi‑Fi |
| 2 | Android opens → scans LAN for port 8080 |
| 3 | Loads the **same live web app** (menu, kitchen, admin, QR orders) |
| 4 | Guest scan / kitchen / admin all share one database on the PC |

If the PC is off, the app can open a limited **offline** copy of the UI.

---

## Menu inside the app

| Menu item | Action |
|-----------|--------|
| Find / Reload Server | Scan Wi‑Fi again |
| Server Settings | Type PC IP manually |
| Offline Mode | Bundled offline UI |
| About | Version / info |

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Cannot find server | Start PC app; same Wi‑Fi; allow port 8080 in Windows Firewall |
| Still offline | ⋮ → Server Settings → `http://PC-IP:8080` |
| Gradle errors | File → Invalidate Caches → restart; use JDK 17 |
| Install blocked | Phone settings → allow install from this source |

---

## Windows Firewall (PC)

If phones cannot connect:

1. Windows Security → Firewall → Allow an app  
2. Allow **Python** on **Private** networks  
   or allow inbound TCP port **8080**

---

Otech Business Systems – Papua New Guinea  
Digital Menu for Restaurants, Hotels & Guest Houses
