# Otech Digital Menu – Android Installation

## Recommended: Install as Progressive Web App (PWA)

This is the easiest and fully featured way to run the system on Android phones and tablets.

### Steps

1. On a Windows/Linux PC, start the Otech server (`Start_Otech_Menu.bat` or `python server.py`).
2. Make sure your Android device is on the **same Wi-Fi network**.
3. On the PC run `ipconfig` (Windows) and note the IPv4 address (e.g. `192.168.1.25`).
4. On the Android phone open **Chrome** and go to:
   ```
   http://192.168.1.25:8080
   ```
   (replace with your actual IP)
5. Tap the three-dot menu (⋮) → **Add to Home screen** or **Install app**.
6. Confirm. An **Otech Menu** icon appears on the home screen.
7. Open it — it launches full-screen like a native app. All features work:
   - Guest menu & ordering
   - Kitchen display
   - Admin panel
   - QR scanning / code entry

### Advantages of PWA
- No Google Play store needed
- Instant updates when you update the server files
- Works offline for the UI (data needs network)
- Same codebase as the Windows/desktop version

## Building a Real APK (Advanced)

If you need a signed `.apk` file that can be installed without a browser:

1. Install **Node.js** and **Android Studio** on a development computer.
2. Install Capacitor:
   ```bash
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "Otech Menu" com.otech.menu
   ```
3. Copy the contents of the `public/` folder into the Capacitor `www` folder.
4. Add Android platform and sync:
   ```bash
   npx cap add android
   npx cap sync
   npx cap open android
   ```
5. In Android Studio build a release APK / AAB and sign it.

Alternatively, contact Otech for a pre-built APK of this exact system.

## Network Tips for Hotels / Restaurants

- Run the server on a dedicated PC or small mini-PC / Raspberry Pi in the back office.
- Use a fixed local IP or host name.
- Optionally put the system behind a reverse proxy (nginx) and use HTTPS + a domain so guests can access from outside the property Wi-Fi (for pre-ordering, etc.).
- Windows Firewall: allow inbound TCP port 8080 for Python.

---
Otech Business Systems – Papua New Guinea
