============================================================
  OTECH DIGITAL MENU - WINDOWS SETUP
============================================================

QUICK START (recommended)
-------------------------
1. Extract the whole "otech-digital-menu" folder to a permanent
   location, e.g.  C:\Otech\DigitalMenu

2. Open the "windows-launcher" folder.

3. Double-click  Setup.bat

   Setup will:
   - Check for Python 3.8+
   - Download and install Python automatically if missing
     (internet required for first-time install only)
   - Create a Desktop shortcut: "Otech Digital Menu"
   - Create a Start Menu shortcut
   - Optionally start the system for you

4. After setup, always start the system by double-clicking
   the Desktop shortcut "Otech Digital Menu".


RUNNING THE APP
---------------
- Double-click the Desktop shortcut
  OR
- Run Start_Otech_Menu.bat

A black window will open (keep it open). Your browser will
open to http://localhost:8080


DEFAULT LOGIN
-------------
  Username: admin
  Password: admin123


REQUIREMENTS
------------
- Windows 10 or Windows 11 (64-bit recommended)
- Internet only needed once if Python is not already installed
- No other software required (no Node, no database install)


IF SETUP CANNOT DOWNLOAD PYTHON
-------------------------------
1. Go to https://www.python.org/downloads/
2. Download Python 3.12 (or newer)
3. Run the installer
4. IMPORTANT: tick the box "Add python.exe to PATH"
5. Finish install, then run Setup.bat again


STOPPING THE SYSTEM
-------------------
Close the black command window, or press Ctrl+C in that window.


NETWORK ACCESS (phones / other PCs)
-----------------------------------
1. Find this PC's IP address: open Command Prompt and type  ipconfig
2. On other devices on the same Wi-Fi open:
   http://YOUR-PC-IP:8080
   Example: http://192.168.1.25:8080


SUPPORT
-------
Otech Business Systems - Papua New Guinea
Digital Menu for Restaurants, Hotels & Guest Houses
============================================================
