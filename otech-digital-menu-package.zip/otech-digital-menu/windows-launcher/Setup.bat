@echo off
setlocal EnableDelayedExpansion
title Otech Digital Menu - Setup
color 0B
cd /d "%~dp0"

echo.

:: Firewall so phones on same Wi-Fi can connect
echo  [INFO] Configuring Windows Firewall for port 8080...
netsh advfirewall firewall delete rule name="Otech Digital Menu 8080" >nul 2>&1
netsh advfirewall firewall add rule name="Otech Digital Menu 8080" dir=in action=allow protocol=TCP localport=8080 >nul 2>&1
if !errorlevel! equ 0 (
    echo  [OK] Port 8080 allowed for same-network access.
) else (
    echo  [WARN] Run Setup as Administrator to open firewall for phones.
)

echo  ============================================================
echo    OTECH DIGITAL MENU ^& ORDER SYSTEM
echo    Full Setup - Prerequisites + Desktop Shortcut
echo  ============================================================
echo.

:: ----------------------------------------------------------
:: 1. Check if running from correct folder
:: ----------------------------------------------------------
if not exist "..\server.py" (
    echo  [ERROR] server.py not found.
    echo  Please run this Setup from the windows-launcher folder
    echo  inside the otech-digital-menu package.
    pause
    exit /b 1
)

:: ----------------------------------------------------------
:: 2. Check for Python
:: ----------------------------------------------------------
set "PYTHON_OK=0"
set "PYTHON_CMD="

where python >nul 2>&1
if !errorlevel! equ 0 (
    for /f "tokens=*" %%i in ('python --version 2^>^&1') do set PYVER=%%i
    echo  [OK] Found: !PYVER!
    python -c "import sys; exit(0 if sys.version_info >= (3,8) else 1)" >nul 2>&1
    if !errorlevel! equ 0 (
        set "PYTHON_OK=1"
        set "PYTHON_CMD=python"
    ) else (
        echo  [WARN] Python found but version is below 3.8
    )
)

if "!PYTHON_OK!"=="0" (
    where python3 >nul 2>&1
    if !errorlevel! equ 0 (
        for /f "tokens=*" %%i in ('python3 --version 2^>^&1') do set PYVER=%%i
        echo  [OK] Found: !PYVER!
        python3 -c "import sys; exit(0 if sys.version_info >= (3,8) else 1)" >nul 2>&1
        if !errorlevel! equ 0 (
            set "PYTHON_OK=1"
            set "PYTHON_CMD=python3"
        )
    )
)

if "!PYTHON_OK!"=="0" (
    echo.
    echo  [INFO] Python 3.8+ is required but was not found.
    echo  Setup will now download and install Python for you.
    echo.
    echo  This requires an internet connection.
    echo.
    choice /C YN /M "  Download and install Python 3.12 now"
    if !errorlevel! equ 2 (
        echo  Setup cancelled. Please install Python manually from:
        echo  https://www.python.org/downloads/
        echo  Important: tick "Add python.exe to PATH" during install.
        pause
        exit /b 1
    )
    call :InstallPython
    if !errorlevel! neq 0 (
        echo  [ERROR] Python installation failed.
        pause
        exit /b 1
    )
    set "PYTHON_OK=1"
    set "PYTHON_CMD=python"
)

echo.
echo  [OK] Python is ready.

:: ----------------------------------------------------------
:: 3. Create desktop shortcut
:: ----------------------------------------------------------
echo.
echo  Creating Desktop shortcut...

set "APP_DIR=%~dp0.."
:: Resolve to absolute path
pushd "%APP_DIR%"
set "APP_DIR=%CD%"
popd

set "SHORTCUT_NAME=Otech Digital Menu"
set "TARGET=%~dp0Start_Otech_Menu.bat"
set "ICON=%~dp0otech-icon.ico"
if not exist "%ICON%" set "ICON=%APP_DIR%\public\img\icon-512.png"
if not exist "%ICON%" set "ICON=%SystemRoot%\System32\SHELL32.dll,13"

:: Use VBScript to create proper shortcut
set "VBS=%TEMP%\otech_create_shortcut.vbs"
(
    echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
    echo sLinkFile = oWS.SpecialFolders^("Desktop"^) ^& "\%SHORTCUT_NAME%.lnk"
    echo Set oLink = oWS.CreateShortcut^(sLinkFile^)
    echo oLink.TargetPath = "%TARGET%"
    echo oLink.WorkingDirectory = "%~dp0"
    echo oLink.Description = "Otech Digital Menu ^& Order System - Restaurant ^& Room Service"
    echo oLink.WindowStyle = 1
    if exist "%~dp0otech-icon.ico" (
        echo oLink.IconLocation = "%~dp0otech-icon.ico"
    ) else if exist "%APP_DIR%\public\img\icon-512.png" (
        echo oLink.IconLocation = "%APP_DIR%\public\img\icon-512.png"
    )
    echo oLink.Save
    echo WScript.Echo "Desktop shortcut created: " ^& sLinkFile
) > "%VBS%"

cscript //nologo "%VBS%"
del "%VBS%" >nul 2>&1

echo  [OK] Desktop shortcut created: "%SHORTCUT_NAME%"

:: Also create Start Menu shortcut (optional)
set "START_MENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
if exist "%START_MENU%" (
    set "VBS2=%TEMP%\otech_startmenu.vbs"
    (
        echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
        echo sLinkFile = "%START_MENU%\%SHORTCUT_NAME%.lnk"
        echo Set oLink = oWS.CreateShortcut^(sLinkFile^)
        echo oLink.TargetPath = "%TARGET%"
        echo oLink.WorkingDirectory = "%~dp0"
        echo oLink.Description = "Otech Digital Menu ^& Order System"
        echo oLink.Save
    ) > "%VBS2%"
    cscript //nologo "%VBS2%" >nul 2>&1
    del "%VBS2%" >nul 2>&1
    echo  [OK] Start Menu shortcut created
)

:: ----------------------------------------------------------
:: 4. Write a small config / launcher helper
:: ----------------------------------------------------------
(
    echo @echo off
    echo cd /d "%APP_DIR%"
    echo if exist "windows-launcher\Start_Otech_Menu.bat" ^(
    echo     call "windows-launcher\Start_Otech_Menu.bat"
    echo ^) else ^(
    echo     echo Cannot find Start_Otech_Menu.bat
    echo     pause
    echo ^)
) > "%~dp0Run_Otech.bat"

:: ----------------------------------------------------------
:: 5. Finish
:: ----------------------------------------------------------
echo.
echo  ============================================================
echo    SETUP COMPLETE
echo  ============================================================
echo.
echo    Desktop shortcut:  "%SHORTCUT_NAME%"
echo    To start the system: double-click the Desktop shortcut
echo.
echo    Default admin login:  admin  /  admin123
echo.
echo    The system runs in your browser at:
echo    http://localhost:8080
echo.
echo  ============================================================
echo.
choice /C YN /M "  Start Otech Digital Menu now"
if !errorlevel! equ 1 (
    echo.
    echo  Starting...
    call "%~dp0Start_Otech_Menu.bat"
) else (
    echo.
    echo  You can start anytime from the Desktop shortcut.
    pause
)
exit /b 0

:: ==========================================================
:: Install Python (silent)
:: ==========================================================
:InstallPython
echo.
echo  Downloading Python 3.12 (Windows 64-bit)...
echo  Please wait...

set "PY_URL=https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe"
set "PY_INSTALLER=%TEMP%\python-3.12.7-amd64.exe"

:: Try PowerShell download first
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%PY_URL%' -OutFile '%PY_INSTALLER%' -UseBasicParsing; exit 0 } catch { exit 1 }"

if not exist "%PY_INSTALLER%" (
    echo  [WARN] PowerShell download failed. Trying curl...
    curl -L -o "%PY_INSTALLER%" "%PY_URL%" 2>nul
)

if not exist "%PY_INSTALLER%" (
    echo  [ERROR] Could not download Python installer.
    echo  Please download manually from https://www.python.org/downloads/
    echo  During install, tick "Add python.exe to PATH".
    exit /b 1
)

echo  [OK] Download complete.
echo  Installing Python (this may take 1-2 minutes)...
echo  Installing for current user with PATH enabled...

:: Silent install: PrependPath, no UI, current user
"%PY_INSTALLER%" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_doc=0 Include_pip=1 SimpleInstall=1

if !errorlevel! neq 0 (
    echo  [WARN] Quiet install returned error. Trying interactive install...
    start /wait "" "%PY_INSTALLER%" PrependPath=1
)

:: Refresh PATH in this session
set "PATH=%LOCALAPPDATA%\Programs\Python\Python312;%LOCALAPPDATA%\Programs\Python\Python312\Scripts;%PATH%"
set "PATH=%ProgramFiles%\Python312;%ProgramFiles%\Python312\Scripts;%PATH%"

:: Verify
where python >nul 2>&1
if !errorlevel! equ 0 (
    echo  [OK] Python installed successfully.
    del "%PY_INSTALLER%" >nul 2>&1
    exit /b 0
)

:: Sometimes need to open a new shell for PATH - check common locations
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set "PATH=%LOCALAPPDATA%\Programs\Python\Python312;%PATH%"
    echo  [OK] Python found at LocalAppData.
    del "%PY_INSTALLER%" >nul 2>&1
    exit /b 0
)

echo  [WARN] Python may have installed but is not yet on PATH.
echo  Please close this window, open a NEW Command Prompt, and run Setup again.
echo  Or restart your computer and run Setup once more.
del "%PY_INSTALLER%" >nul 2>&1
exit /b 1
