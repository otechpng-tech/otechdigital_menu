' Otech Digital Menu - Create Desktop Shortcut with Logo Icon
Option Explicit
Dim oWS, sLinkFile, oLink, fso, scriptDir, startBat, iconPath

Set fso = CreateObject("Scripting.FileSystemObject")
Set oWS = CreateObject("WScript.Shell")

scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
startBat = scriptDir & "\Start_Otech_Menu.bat"
iconPath = scriptDir & "\otech-icon.ico"

If Not fso.FileExists(startBat) Then
  MsgBox "Start_Otech_Menu.bat not found." & vbCrLf & "Run this from the windows-launcher folder.", vbCritical, "Otech Setup"
  WScript.Quit 1
End If

sLinkFile = oWS.SpecialFolders("Desktop") & "\Otech Digital Menu.lnk"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = startBat
oLink.WorkingDirectory = scriptDir
oLink.Description = "Otech Digital Menu & Order System - Restaurant & Room Service"
oLink.WindowStyle = 1
If fso.FileExists(iconPath) Then
  oLink.IconLocation = iconPath
Else
  oLink.IconLocation = "%SystemRoot%\System32\SHELL32.dll,13"
End If
oLink.Save

MsgBox "Desktop shortcut created with Otech logo!" & vbCrLf & vbCrLf & _
       "Double-click ""Otech Digital Menu"" on your Desktop to start." & vbCrLf & vbCrLf & _
       "Default login: admin / admin123" & vbCrLf & vbCrLf & _
       "On the same Wi-Fi, other devices open the IP shown in the server window.", vbInformation, "Otech Digital Menu"
