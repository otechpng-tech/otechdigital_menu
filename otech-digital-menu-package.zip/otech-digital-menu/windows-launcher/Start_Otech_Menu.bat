@echo off
setlocal EnableDelayedExpansion
title Otech Digital Menu - Server
color 0A
cd /d "%~dp0\.."

echo.
echo  ============================================================
echo    OTECH DIGITAL MENU - STARTING SERVER
echo  ============================================================
echo.

:: Open Windows Firewall for port 8080 (same Wi-Fi phones/tablets)
netsh advfirewall firewall show rule name="Otech Digital Menu 8080" >nul 2>&1
if !errorlevel! neq 0 (
    echo  [INFO] Adding Windows Firewall rule for port 8080...
    netsh advfirewall firewall add rule name="Otech Digital Menu 8080" dir=in action=allow protocol=TCP localport=8080 >nul 2>&1
    if !errorlevel! equ 0 (
        echo  [OK] Firewall allows port 8080 for same-network devices.
    ) else (
        echo  [WARN] Could not add firewall rule automatically.
        echo         Run this file as Administrator once, or allow Python in Firewall.
    )
) else (
    echo  [OK] Firewall rule already present for port 8080.
)

:: Find Python
set "PY="
where python >nul 2>&1 && set "PY=python"
if not defined PY where python3 >nul 2>&1 && set "PY=python3"
if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if not defined PY if exist "%ProgramFiles%\Python312\python.exe" set "PY=%ProgramFiles%\Python312\python.exe"

if not defined PY (
    echo  [ERROR] Python was not found. Run Setup.bat first.
    pause
    exit /b 1
)

if not exist "server.py" (
    echo  [ERROR] server.py not found in %CD%
    pause
    exit /b 1
)

echo.
echo  IMPORTANT FOR PHONES ON SAME Wi-Fi:
echo  - Use the LAN address printed below (NOT only localhost)
echo  - Phone and PC must be on the same Wi-Fi
echo  - Open QR codes AFTER server is running
echo.
echo  Starting...
echo.

:: Open browser after short delay
start "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:8080"

"%PY%" server.py
if !errorlevel! neq 0 (
    echo.
    echo  [ERROR] Server stopped with an error.
    pause
)
endlocal
